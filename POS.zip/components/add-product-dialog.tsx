"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface AddProductDialogProps {
  open: boolean
  onClose: () => void
  onAdd: (product: any) => void
}

export default function AddProductDialog({ open, onClose, onAdd }: AddProductDialogProps) {
  const [product, setProduct] = useState({
    name: "",
    category: "",
    serialNumber: "",
    stock: "",
    price: "",
    lowStockThreshold: 3,
    vendor: "",
  })

  const handleChange = (field: string, value: string | number) => {
    setProduct({ ...product, [field]: value })
  }

  const handleSubmit = () => {
    onAdd(product)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add New Product</DialogTitle>
          <DialogDescription>Enter the details of the new product to add to your inventory.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Name
            </Label>
            <Input
              id="name"
              value={product.name}
              onChange={(e) => handleChange("name", e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="category" className="text-right">
              Category
            </Label>
            <Select onValueChange={(value) => handleChange("category", value)} value={product.category}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Phones">Phones</SelectItem>
                <SelectItem value="Accessories">Accessories</SelectItem>
                <SelectItem value="Speakers">Speakers</SelectItem>
                <SelectItem value="Printers">Printers</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="serialNumber" className="text-right">
              Serial/IMEI
            </Label>
            <Input
              id="serialNumber"
              value={product.serialNumber}
              onChange={(e) => handleChange("serialNumber", e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="stock" className="text-right">
              Stock
            </Label>
            <Input
              id="stock"
              type="number"
              value={product.stock}
              onChange={(e) => {
                const value = e.target.value === "" ? "" : Number(e.target.value)
                handleChange("stock", value)
              }}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="price" className="text-right">
              Price
            </Label>
            <Input
              id="price"
              type="number"
              value={product.price}
              onChange={(e) => {
                const value = e.target.value === "" ? "" : Number(e.target.value)
                handleChange("price", value)
              }}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="vendor" className="text-right">
              Vendor
            </Label>
            <Input
              id="vendor"
              value={product.vendor}
              onChange={(e) => handleChange("vendor", e.target.value)}
              className="col-span-3"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>Add Product</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
