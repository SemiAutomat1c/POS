"use client"

import { useState, useEffect } from "react"
import { Plus, Search, Filter, AlertTriangle, Download, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { initializeDB } from "@/lib/db"
import AddProductDialog from "@/components/add-product-dialog"

export default function InventoryPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [products, setProducts] = useState<any[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [showAddDialog, setShowAddDialog] = useState(false)

  useEffect(() => {
    const loadData = async () => {
      try {
        await initializeDB()
        // In a real app, we would fetch actual data from IndexedDB
        // For now, we'll use mock data
        const mockProducts = [
          {
            id: 1,
            name: "iPhone 13 Pro",
            category: "Phones",
            serialNumber: "IMEI: 352789102345678",
            stock: 5,
            price: 65990,
            lowStockThreshold: 3,
            vendor: "Apple",
          },
          {
            id: 2,
            name: "Samsung Galaxy S21",
            category: "Phones",
            serialNumber: "IMEI: 490123456789012",
            stock: 8,
            price: 49990,
            lowStockThreshold: 3,
            vendor: "Samsung",
          },
          {
            id: 3,
            name: "JBL Flip 5",
            category: "Speakers",
            serialNumber: "SN: JBL5678901",
            stock: 12,
            price: 5490,
            lowStockThreshold: 5,
            vendor: "JBL",
          },
          {
            id: 4,
            name: "AirPods Pro",
            category: "Accessories",
            serialNumber: "SN: APP7890123",
            stock: 15,
            price: 14990,
            lowStockThreshold: 5,
            vendor: "Apple",
          },
          {
            id: 5,
            name: "HP LaserJet Pro",
            category: "Printers",
            serialNumber: "SN: HPLJ1234567",
            stock: 2,
            price: 12990,
            lowStockThreshold: 3,
            vendor: "HP",
          },
          {
            id: 6,
            name: "Samsung Galaxy Buds",
            category: "Accessories",
            serialNumber: "SN: BUD78901234",
            stock: 7,
            price: 7990,
            lowStockThreshold: 5,
            vendor: "Samsung",
          },
        ]
        setProducts(mockProducts)
      } catch (error) {
        console.error("Failed to load products:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.serialNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.vendor.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleAddProduct = (newProduct: any) => {
    // Convert empty string values to numbers
    const processedProduct = {
      ...newProduct,
      id: products.length + 1,
      stock: newProduct.stock === "" ? 0 : Number(newProduct.stock),
      price: newProduct.price === "" ? 0 : Number(newProduct.price),
      lowStockThreshold: Number(newProduct.lowStockThreshold),
    }
    setProducts([...products, processedProduct])
    setShowAddDialog(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Inventory</h1>
          <p className="text-muted-foreground">Manage your product inventory</p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={() => setShowAddDialog(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Product
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Export as CSV</DropdownMenuItem>
              <DropdownMenuItem>Export as Excel</DropdownMenuItem>
              <DropdownMenuItem>Print Inventory</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="outline">
            <Upload className="mr-2 h-4 w-4" />
            Import
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <Tabs defaultValue="all">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
              <TabsList>
                <TabsTrigger value="all">All Products</TabsTrigger>
                <TabsTrigger value="low-stock">Low Stock</TabsTrigger>
                <TabsTrigger value="phones">Phones</TabsTrigger>
                <TabsTrigger value="accessories">Accessories</TabsTrigger>
              </TabsList>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search products..."
                    className="pl-8 w-full sm:w-[300px]"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Button variant="outline" size="icon">
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <TabsContent value="all" className="m-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Serial/IMEI</TableHead>
                      <TableHead>Stock</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Vendor</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center">
                          Loading products...
                        </TableCell>
                      </TableRow>
                    ) : filteredProducts.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center">
                          No products found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredProducts.map((product) => (
                        <TableRow key={product.id}>
                          <TableCell className="font-medium">{product.name}</TableCell>
                          <TableCell>{product.category}</TableCell>
                          <TableCell className="font-mono text-xs">{product.serialNumber}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {product.stock <= product.lowStockThreshold ? (
                                <>
                                  <span className="text-destructive">{product.stock}</span>
                                  <AlertTriangle className="h-4 w-4 text-destructive" />
                                </>
                              ) : (
                                product.stock
                              )}
                            </div>
                          </TableCell>
                          <TableCell>₱{product.price.toLocaleString()}</TableCell>
                          <TableCell>{product.vendor}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  Actions
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem>Edit</DropdownMenuItem>
                                <DropdownMenuItem>Add Stock</DropdownMenuItem>
                                <DropdownMenuItem>View History</DropdownMenuItem>
                                <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="low-stock" className="m-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Serial/IMEI</TableHead>
                      <TableHead>Stock</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Vendor</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center">
                          Loading products...
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredProducts
                        .filter((product) => product.stock <= product.lowStockThreshold)
                        .map((product) => (
                          <TableRow key={product.id}>
                            <TableCell className="font-medium">{product.name}</TableCell>
                            <TableCell>{product.category}</TableCell>
                            <TableCell className="font-mono text-xs">{product.serialNumber}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <span className="text-destructive">{product.stock}</span>
                                <AlertTriangle className="h-4 w-4 text-destructive" />
                              </div>
                            </TableCell>
                            <TableCell>₱{product.price.toLocaleString()}</TableCell>
                            <TableCell>{product.vendor}</TableCell>
                            <TableCell className="text-right">
                              <Button variant="outline" size="sm">
                                Add Stock
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            {/* Other tabs would have similar content */}
          </Tabs>
        </CardContent>
      </Card>

      {showAddDialog && (
        <AddProductDialog open={showAddDialog} onClose={() => setShowAddDialog(false)} onAdd={handleAddProduct} />
      )}
    </div>
  )
}
